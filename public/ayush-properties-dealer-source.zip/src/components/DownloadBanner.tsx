import React, { useState } from 'react';
import { Download, CheckCircle2, CloudUpload, Loader2, ExternalLink, HelpCircle } from 'lucide-react';
import { downloadNetlifyZip } from '../utils/downloader';

export const DownloadBanner: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const handleDownload = async () => {
    setLoading(true);
    setSuccess(false);
    setStatus('Preparing your Netlify ZIP file...');

    const ok = await downloadNetlifyZip((msg) => {
      setStatus(msg);
    });

    setLoading(false);
    if (ok) {
      setSuccess(true);
      setStatus('ZIP File Download Shuru Ho Gaya Hai! ✅');
    } else {
      setStatus('Direct download failed. Please click alternative link below.');
    }
  };

  return (
    <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-slate-950 px-4 py-3 border-b-2 border-amber-600 shadow-md">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-center md:text-left">
        {/* Left message */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-slate-950 text-amber-400 flex items-center justify-center shrink-0 shadow-xs">
            <CloudUpload className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 justify-center md:justify-start">
              <span className="font-extrabold text-sm tracking-tight text-slate-950 uppercase">
                Netlify Hosting ZIP Package Ready
              </span>
              <span className="bg-slate-950 text-amber-300 text-[10px] font-bold px-1.5 py-0.5 rounded">
                1-Click Download
              </span>
            </div>
            <p className="text-xs text-slate-900 font-medium">
              Click the button below to download the deployable ZIP for <strong>app.netlify.com/drop</strong>.
            </p>
          </div>
        </div>

        {/* Right Action buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          {status && (
            <span className="text-xs font-bold text-slate-950 bg-white/70 px-2.5 py-1 rounded-md flex items-center gap-1.5">
              {loading && <Loader2 className="w-3.5 h-3.5 animate-spin text-slate-900" />}
              {success && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />}
              <span>{status}</span>
            </span>
          )}

          <button
            onClick={handleDownload}
            disabled={loading}
            className="inline-flex items-center gap-2 px-4 py-2 bg-slate-950 hover:bg-slate-900 text-white rounded-lg text-xs font-bold transition-all active:scale-95 shadow-md cursor-pointer disabled:opacity-75"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
            ) : (
              <Download className="w-4 h-4 text-amber-400" />
            )}
            <span>DOWNLOAD NETLIFY ZIP NOW</span>
          </button>

          <button
            onClick={() => setShowGuide(!showGuide)}
            className="p-2 rounded-lg bg-white/40 hover:bg-white/60 text-slate-950 text-xs font-semibold flex items-center gap-1"
            title="Kaise host karein?"
          >
            <HelpCircle className="w-4 h-4" />
            <span className="hidden sm:inline">Guide</span>
          </button>
        </div>
      </div>

      {/* Guide Dropdown */}
      {showGuide && (
        <div className="mt-3 pt-3 border-t border-amber-600/30 text-xs text-slate-950 max-w-7xl mx-auto bg-amber-300/60 p-3 rounded-lg text-left">
          <p className="font-bold mb-1">Netlify par host karne ke 3 aasan steps:</p>
          <ol className="list-decimal list-inside space-y-1 text-slate-900">
            <li>Upar diye gaye <strong>"DOWNLOAD NETLIFY ZIP NOW"</strong> button par click karein.</li>
            <li>Apne browser me <strong><a href="https://app.netlify.com/drop" target="_blank" rel="noopener noreferrer" className="underline font-bold">app.netlify.com/drop</a></strong> open karein.</li>
            <li>Downloaded <code>ayush-properties-dealer-netlify.zip</code> ko wahan drag karke drop kar dein. 10 second me website LIVE ho jayegi!</li>
          </ol>
        </div>
      )}
    </div>
  );
};
