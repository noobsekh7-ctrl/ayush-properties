import React, { useState } from 'react';
import { Download, CloudUpload, Loader2, CheckCircle2, X } from 'lucide-react';
import { downloadNetlifyZip } from '../utils/downloader';

export const FloatingDownload: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');

  const handleDownload = async () => {
    setLoading(true);
    setShowToast(true);
    setToastMsg('ZIP package create ho raha hai...');

    const success = await downloadNetlifyZip((msg) => {
      setToastMsg(msg);
    });

    setLoading(false);
    if (success) {
      setDownloadSuccess(true);
      setToastMsg('Download shuru ho gaya! Ab app.netlify.com/drop par upload karein.');
    } else {
      setToastMsg('Download failed. Please try again.');
    }
  };

  return (
    <>
      {/* Floating Action Button (Visible on both desktop & tablet/mobile) */}
      <div className="fixed bottom-18 sm:bottom-6 right-4 sm:right-6 z-40 flex flex-col items-end gap-2">
        {/* Toast popup */}
        {showToast && (
          <div className="bg-slate-900 border border-amber-400 text-white text-xs p-3.5 rounded-xl shadow-2xl max-w-xs flex items-start gap-2.5 animate-bounce-in">
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin text-amber-400 shrink-0 mt-0.5" />
            ) : downloadSuccess ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            ) : null}
            <div className="flex-1">
              <p className="font-semibold text-amber-300">Netlify Package</p>
              <p className="text-slate-300 text-[11px] mt-0.5">{toastMsg}</p>
            </div>
            <button
              onClick={() => setShowToast(false)}
              className="text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        <button
          onClick={handleDownload}
          disabled={loading}
          className="flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400 hover:brightness-105 active:scale-95 text-slate-950 font-bold text-xs sm:text-sm rounded-full shadow-2xl border-2 border-slate-950 cursor-pointer transition-all"
          title="Click to Download Netlify ZIP"
        >
          {loading ? (
            <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
          ) : (
            <CloudUpload className="w-4 h-4 text-slate-950" />
          )}
          <span>Download Netlify ZIP</span>
        </button>
      </div>
    </>
  );
};
