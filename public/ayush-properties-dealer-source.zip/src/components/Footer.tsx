import React from 'react';
import { Building2, Phone, MapPin, MessageCircle, Download, CloudUpload } from 'lucide-react';
import { SITE_CONFIG, getWhatsAppUrl } from '../config/siteConfig';
import { downloadNetlifyZip } from '../utils/downloader';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#071527] text-white border-t border-slate-800 text-left">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand & Introduction */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-[#0B1F3A] font-bold">
                <Building2 className="w-4 h-4 text-[#0B1F3A]" />
              </div>
              <span className="font-serif font-bold text-base text-white tracking-wide">
                {SITE_CONFIG.businessName}
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Trusted real estate dealer and property consultant in Bokaro Steel City. Dedicated to
              transparent property transactions, clear titles, and fair guidance.
            </p>
            <div className="pt-2 text-xs text-amber-300 font-medium flex items-center gap-1.5">
              <span>Google 5.0 Rating (53 Reviews)</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-serif font-bold text-sm text-white mb-3 tracking-wide">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>
                <a href="#home" className="hover:text-amber-300 transition-colors">
                  Home
                </a>
              </li>
              <li>
                <a href="#properties" className="hover:text-amber-300 transition-colors">
                  Featured Properties
                </a>
              </li>
              <li>
                <a href="#services" className="hover:text-amber-300 transition-colors">
                  Buy, Sell & Plots
                </a>
              </li>
              <li>
                <a href="#why-us" className="hover:text-amber-300 transition-colors">
                  Why Choose Us
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-amber-300 transition-colors">
                  About Ayush Properties
                </a>
              </li>
              <li>
                <a href="#reviews" className="hover:text-amber-300 transition-colors">
                  Google Reviews
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-amber-300 transition-colors">
                  Contact & Office
                </a>
              </li>
            </ul>
          </div>

          {/* Property Types in Bokaro */}
          <div>
            <h4 className="font-serif font-bold text-sm text-white mb-3 tracking-wide">
              Bokaro Properties
            </h4>
            <ul className="space-y-2 text-xs text-slate-300">
              <li>Residential Plots (Sector 4 & City Center)</li>
              <li>Independent Duplex & Bungalows</li>
              <li>2 & 3 BHK Apartments in Chas & Bokaro</li>
              <li>Commercial Shops & Showrooms</li>
              <li>Title Verification & Registry Guidance</li>
            </ul>
          </div>

          {/* Contact Direct */}
          <div>
            <h4 className="font-serif font-bold text-sm text-white mb-3 tracking-wide">
              Contact Dealer
            </h4>
            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{SITE_CONFIG.address.full}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a
                  href={SITE_CONFIG.phoneTel}
                  className="hover:text-amber-300 font-mono font-medium"
                >
                  {SITE_CONFIG.phoneDisplay}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <a
                  href={getWhatsAppUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-300"
                >
                  WhatsApp: +{SITE_CONFIG.whatsappNumber}
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Netlify Deployment Ready Banner */}
        <div className="mt-10 p-5 rounded-2xl bg-gradient-to-r from-slate-900 to-[#0B1F3A] border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-lg">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
              <CloudUpload className="w-4 h-4 text-amber-400" />
              <span>Netlify Hosting Ready (.ZIP Package)</span>
            </div>
            <p className="text-xs text-slate-300 max-w-xl">
              Download the production-ready build. Simply upload or drag-and-drop this ZIP into{' '}
              <span className="text-white font-medium">app.netlify.com/drop</span> to host the website live instantly.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            <button
              onClick={() => downloadNetlifyZip()}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-all shadow-md shrink-0 w-full sm:w-auto cursor-pointer active:scale-95"
            >
              <Download className="w-4 h-4" />
              <span>Download Netlify ZIP (Deploy Ready)</span>
            </button>

            <a
              href="/ayush-properties-dealer-source.zip"
              download="ayush-properties-dealer-source.zip"
              className="inline-flex items-center justify-center gap-2 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold rounded-lg transition-all shrink-0 w-full sm:w-auto"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>Full Source Code (.zip)</span>
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {currentYear} {SITE_CONFIG.businessName}. All rights reserved.
          </p>
          <p className="text-[11px] text-slate-500 text-center sm:text-right">
            KD-22, City Center, Sector 4, Bokaro Steel City, Jharkhand 827004
          </p>
        </div>
      </div>
    </footer>
  );
};
