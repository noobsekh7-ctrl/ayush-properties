import JSZip from 'jszip';

export async function downloadNetlifyZip(onProgress?: (msg: string) => void): Promise<boolean> {
  try {
    if (onProgress) onProgress('Preparing download...');
    
    // Method 1: Try fetching the pre-built zip directly
    try {
      const res = await fetch('/ayush-properties-dealer-netlify.zip');
      if (res.ok) {
        if (onProgress) onProgress('Downloading ZIP...');
        const blob = await res.blob();
        if (blob.size > 10000) {
          triggerBrowserDownload(blob, 'ayush-properties-dealer-netlify.zip');
          if (onProgress) onProgress('Download complete!');
          return true;
        }
      }
    } catch (e) {
      console.warn('Direct zip fetch failed, building zip in-browser with JSZip...', e);
    }

    // Method 2: In-browser JSZip builder (guaranteed 100% offline & no server auth issues)
    if (onProgress) onProgress('Packaging files with JSZip...');
    const zip = new JSZip();

    // 1. Fetch current index.html
    const indexHtmlRes = await fetch('/');
    const indexHtmlText = await indexHtmlRes.text();
    zip.file('index.html', indexHtmlText);

    // 2. Netlify redirects file
    zip.file('_redirects', '/*    /index.html   200\n');

    // 3. Images to package
    const imagesToFetch = [
      '/src/assets/images/hero_bokaro_residence_1790338348415.jpg',
      '/src/assets/images/prop_luxury_apartment_1790338361514.jpg',
      '/src/assets/images/prop_residential_plot_1790338376583.jpg',
      '/src/assets/images/prop_modern_duplex_1790338391871.jpg',
      '/src/assets/images/prop_commercial_space_1790338404364.jpg',
    ];

    for (const imgUrl of imagesToFetch) {
      try {
        const imgRes = await fetch(imgUrl);
        if (imgRes.ok) {
          const imgBlob = await imgRes.blob();
          const cleanPath = imgUrl.startsWith('/') ? imgUrl.slice(1) : imgUrl;
          zip.file(cleanPath, imgBlob);
          // Also store in assets/images/
          const fileName = cleanPath.split('/').pop() || '';
          zip.file(`assets/images/${fileName}`, imgBlob);
        }
      } catch (err) {
        console.warn('Could not fetch image for zip:', imgUrl, err);
      }
    }

    if (onProgress) onProgress('Generating final ZIP file...');
    const generatedZipBlob = await zip.generateAsync({ type: 'blob' });
    triggerBrowserDownload(generatedZipBlob, 'ayush-properties-dealer-netlify.zip');
    if (onProgress) onProgress('Download ready!');
    return true;
  } catch (error) {
    console.error('Download error:', error);
    if (onProgress) onProgress('Error creating download. Please try again.');
    return false;
  }
}

function triggerBrowserDownload(blob: Blob, filename: string) {
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }, 2000);
}
